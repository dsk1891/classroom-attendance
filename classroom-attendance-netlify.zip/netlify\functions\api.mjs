import { getStore } from "@netlify/blobs";
import QRCode from "qrcode";
import { randomUUID, timingSafeEqual } from "node:crypto";

const MAX_BODY_BYTES = 1024 * 1024;

function response(statusCode, value, headers = {}) {
  return {
    statusCode,
    headers: { "Content-Type": "application/json; charset=utf-8", "Cache-Control": "no-store", ...headers },
    body: typeof value === "string" ? value : JSON.stringify(value),
  };
}

function migrateStudent(student) {
  return {
    ...student,
    misNumber: student.misNumber ?? student.studentId ?? "",
    departmentName: student.departmentName ?? student.className ?? "",
  };
}

async function loadDatabase() {
  const store = getStore("classroom-attendance");
  const stored = await store.getWithMetadata("database", { type: "json", consistency: "strong" });
  const database = stored?.data || { students: [], sessions: [] };
  if (!Array.isArray(database.students) || !Array.isArray(database.sessions)) {
    throw new Error("Invalid attendance database in Netlify Blobs.");
  }
  database.students = database.students.map(migrateStudent);
  database.sessions = database.sessions.map((session) => ({
    ...session,
    roster: Array.isArray(session.roster)
      ? session.roster.map(migrateStudent)
      : database.students.map(migrateStudent),
    attendance: session.attendance || {},
  }));
  return { database, etag: stored?.etag };
}

async function saveDatabase(database, etag) {
  const store = getStore("classroom-attendance");
  const result = await store.setJSON(
    "database",
    database,
    etag ? { onlyIfMatch: etag } : { onlyIfNew: true },
  );
  if (!result.modified) {
    throw Object.assign(new Error("Another request changed attendance data. Please retry."), {
      statusCode: 409,
      retryable: true,
    });
  }
}

function parseRequestBody(event) {
  const body = event.isBase64Encoded
    ? Buffer.from(event.body || "", "base64").toString("utf8")
    : event.body || "";
  if (Buffer.byteLength(body) > MAX_BODY_BYTES) {
    throw Object.assign(new Error("Request body is too large."), { statusCode: 413 });
  }
  try {
    const parsed = JSON.parse(body || "{}");
    if (!parsed || typeof parsed !== "object" || Array.isArray(parsed)) {
      throw new Error("Request body must be a JSON object.");
    }
    return parsed;
  } catch {
    throw Object.assign(new Error("Request body must be valid JSON."), { statusCode: 400 });
  }
}

function validateStudents(students, existingStudents) {
  if (!Array.isArray(students) || students.length === 0) {
    return { error: "Choose a CSV file containing at least one student." };
  }
  if (students.length > 2000) return { error: "Import is limited to 2,000 students at a time." };
  const knownMisNumbers = new Set(existingStudents.map((student) => student.misNumber.toLowerCase()));
  const errors = [];
  const validated = students.map((row, index) => {
    const source = row && typeof row === "object" && !Array.isArray(row) ? row : {};
    const student = {
      name: typeof source.name === "string" ? source.name.trim() : "",
      misNumber: typeof source.misNumber === "string" ? source.misNumber.trim() : "",
      departmentName: typeof source.departmentName === "string" ? source.departmentName.trim() : "",
    };
    const rowErrors = [];
    if (!student.name || !student.misNumber || !student.departmentName) {
      rowErrors.push("Student name, MIS number, and department name are required.");
    } else if (knownMisNumbers.has(student.misNumber.toLowerCase())) {
      rowErrors.push(`MIS number "${student.misNumber}" is already in use.`);
    }
    if (student.name.length > 80 || student.misNumber.length > 32 || student.departmentName.length > 50) {
      rowErrors.push("A field exceeds its maximum length.");
    }
    if (rowErrors.length) {
      errors.push({ row: index + 2, messages: rowErrors });
      return null;
    }
    knownMisNumbers.add(student.misNumber.toLowerCase());
    return { id: randomUUID(), ...student };
  });
  if (errors.length) return { error: "No students were imported. Fix the listed rows and try again.", rows: errors };
  return { students: validated };
}

function sessionDate() {
  const date = new Date();
  return `${date.getFullYear()}-${String(date.getMonth() + 1).padStart(2, "0")}-${String(date.getDate()).padStart(2, "0")}`;
}

function csvCell(value) {
  const text = String(value ?? "");
  const safeText = /^\s*[=+\-@]/.test(text) ? `'${text}` : text;
  return `"${safeText.replaceAll('"', '""')}"`;
}

function csvResponse(session) {
  const rows = [
    ["Session", "MIS Number", "Student Name", "Department Name", "Status", "Marked At"],
    ...session.roster.map((student) => {
      const record = session.attendance[student.id];
      return [
        session.title,
        student.misNumber,
        student.name,
        student.departmentName,
        record ? "Present" : "Absent",
        record?.scannedAt || "",
      ];
    }),
  ];
  const body = `\uFEFF${rows.map((row) => row.map(csvCell).join(",")).join("\r\n")}`;
  return {
    statusCode: 200,
    headers: {
      "Content-Type": "text/csv; charset=utf-8",
      "Content-Disposition": `attachment; filename="attendance-${session.date}.csv"`,
    },
    body,
    isBase64Encoded: false,
  };
}

function normalizePath(event) {
  const rawPath = new URL(event.rawUrl || "https://netlify.local/").pathname;
  const functionPrefix = "/.netlify/functions/api";
  if (rawPath.startsWith(functionPrefix)) return `/api${rawPath.slice(functionPrefix.length)}`;
  if (event.path?.startsWith(functionPrefix)) return `/api${event.path.slice(functionPrefix.length)}`;
  return rawPath;
}

function siteOrigin(event) {
  const headers = event.headers || {};
  const forwardedHost = headers["x-forwarded-host"] || headers.host || "localhost";
  const forwardedProto = headers["x-forwarded-proto"] || "https";
  return `${forwardedProto}://${forwardedHost}`.replace(/\/+$/, "");
}

async function handleApiAttempt(event) {
  try {
    const path = normalizePath(event);
    const method = event.httpMethod || event.requestContext?.http?.method || "GET";
    const publicCheckin = /^\/api\/checkin\/[^/]+$/.test(path) && ["GET", "POST"].includes(method);
    const expectedPassword = process.env.TEACHER_PASSWORD || "";
    if (!publicCheckin) {
      if (expectedPassword.length < 12) {
        return response(503, { error: "Set a teacher password of at least 12 characters in Netlify environment variables." });
      }
      const headers = event.headers || {};
      const suppliedPassword = headers["x-teacher-password"] || headers["X-Teacher-Password"] || "";
      const expectedBuffer = Buffer.from(expectedPassword);
      const suppliedBuffer = Buffer.from(suppliedPassword);
      const authorized = suppliedBuffer.length === expectedBuffer.length
        && timingSafeEqual(suppliedBuffer, expectedBuffer);
      if (!authorized) return response(401, { error: "Teacher password required." });
    }
    const { database, etag } = await loadDatabase();

    if (method === "GET" && path === "/api/state") {
      return response(200, {
        students: database.students,
        sessions: [...database.sessions].reverse(),
        localUrl: siteOrigin(event),
      });
    }

    if (method === "POST" && (path === "/api/students" || path === "/api/students/import")) {
      if (database.sessions.some((session) => session.status === "active")) {
        return response(409, { error: "End the active attendance session before changing the roster." });
      }
      const body = parseRequestBody(event);
      const result = validateStudents(path === "/api/students" ? [body] : body.students, database.students);
      if (result.error) return response(400, result);
      if (path === "/api/students") {
        database.students.push(result.students[0]);
        await saveDatabase(database, etag);
        return response(201, { student: result.students[0] });
      }
      database.students.push(...result.students);
      await saveDatabase(database, etag);
      return response(201, { imported: result.students.length });
    }

    const deleteMatch = path.match(/^\/api\/students\/([^/]+)$/);
    if (method === "DELETE" && deleteMatch) {
      if (database.sessions.some((session) => session.status === "active")) {
        return response(409, { error: "End the active attendance session before changing the roster." });
      }
      const id = decodeURIComponent(deleteMatch[1]);
      const index = database.students.findIndex((student) => student.id === id);
      if (index < 0) return response(404, { error: "Student not found." });
      database.students.splice(index, 1);
      await saveDatabase(database, etag);
      return response(200, { ok: true });
    }

    if (method === "POST" && path === "/api/sessions") {
      const body = parseRequestBody(event);
      const title = typeof body.title === "string" ? body.title.trim() : "";
      if (!title || title.length > 80) {
        return response(400, { error: "Enter a class or session name up to 80 characters." });
      }
      if (!database.students.length) return response(400, { error: "Add at least one student before starting attendance." });
      if (database.sessions.some((session) => session.status === "active")) {
        return response(409, { error: "End the active session before starting another." });
      }
      const session = {
        id: randomUUID(),
        title,
        date: sessionDate(),
        startedAt: new Date().toISOString(),
        status: "active",
        roster: database.students.map((student) => ({ ...student })),
        attendance: {},
      };
      database.sessions.push(session);
      await saveDatabase(database, etag);
      return response(201, { session });
    }

    const qrMatch = path.match(/^\/api\/sessions\/([^/]+)\/qr$/);
    if (method === "GET" && qrMatch) {
      const session = database.sessions.find((item) => item.id === decodeURIComponent(qrMatch[1]));
      if (!session || session.status !== "active") return response(404, { error: "Active session not found." });
      const checkinUrl = `${siteOrigin(event)}/checkin?session=${encodeURIComponent(session.id)}`;
      const dataUrl = await QRCode.toDataURL(checkinUrl, { errorCorrectionLevel: "M", margin: 2, width: 300 });
      return response(200, { dataUrl, checkinUrl });
    }

    const checkinMatch = path.match(/^\/api\/checkin\/([^/]+)$/);
    if (checkinMatch) {
      const session = database.sessions.find((item) => item.id === decodeURIComponent(checkinMatch[1]));
      if (!session || session.status !== "active") {
        return response(404, { error: "This attendance session is no longer active." });
      }
      if (method === "GET") return response(200, { title: session.title, date: session.date });
      if (method === "POST") {
        const body = parseRequestBody(event);
        const misNumber = typeof body.misNumber === "string" ? body.misNumber.trim() : "";
        const student = database.students.find((item) => item.misNumber.toLowerCase() === misNumber.toLowerCase());
        if (!student || !session.roster.some((item) => item.id === student.id)) {
          return response(404, { error: "MIS number not found in this class roster. Check it and try again." });
        }
        if (session.attendance[student.id]) return response(409, { error: "Your attendance has already been recorded." });
        session.attendance[student.id] = { scannedAt: new Date().toISOString() };
        await saveDatabase(database, etag);
        return response(201, { name: student.name });
      }
    }

    const attendanceMatch = path.match(/^\/api\/sessions\/([^/]+)\/attendance$/);
    if (method === "POST" && attendanceMatch) {
      const session = database.sessions.find((item) => item.id === decodeURIComponent(attendanceMatch[1]));
      if (!session || session.status !== "active") return response(404, { error: "No active attendance session was found." });
      const body = parseRequestBody(event);
      const studentId = typeof body.studentId === "string" ? body.studentId : "";
      if (!session.roster.some((student) => student.id === studentId)) {
        return response(404, { error: "Student not found in this session roster." });
      }
      if (session.attendance[studentId]) delete session.attendance[studentId];
      else session.attendance[studentId] = { scannedAt: new Date().toISOString() };
      await saveDatabase(database, etag);
      return response(200, { ok: true });
    }

    const endMatch = path.match(/^\/api\/sessions\/([^/]+)\/end$/);
    if (method === "POST" && endMatch) {
      const session = database.sessions.find((item) => item.id === decodeURIComponent(endMatch[1]));
      if (!session || session.status !== "active") return response(409, { error: "This session is not active." });
      session.status = "ended";
      session.endedAt = new Date().toISOString();
      await saveDatabase(database, etag);
      return response(200, { ok: true });
    }

    const reportMatch = path.match(/^\/api\/sessions\/([^/]+)\/report\.csv$/);
    if (method === "GET" && reportMatch) {
      const session = database.sessions.find((item) => item.id === decodeURIComponent(reportMatch[1]));
      if (!session) return response(404, { error: "Attendance session not found." });
      return csvResponse(session);
    }

    return response(404, { error: "API endpoint not found." });
  } catch (error) {
    if (error.statusCode) {
      return response(error.statusCode, { error: error.message }, error.retryable ? { "X-Retryable-Conflict": "true" } : {});
    }
    console.error(error);
    return response(500, { error: "The attendance service could not complete the request." });
  }
}

export async function handleApi(event) {
  for (let attempt = 0; attempt < 3; attempt += 1) {
    const result = await handleApiAttempt(event);
    if (result.headers?.["X-Retryable-Conflict"] !== "true") return result;
    if (attempt < 2) await new Promise((resolve) => setTimeout(resolve, 20 * (attempt + 1)));
  }
  return response(409, { error: "Attendance changed repeatedly. Please retry your request." });
}

export const handler = handleApi;
